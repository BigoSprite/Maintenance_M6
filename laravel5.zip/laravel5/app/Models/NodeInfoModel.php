<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NodeInfoModel extends Model
{
    protected $table = 'nodeinfo';
    public $timestamps = false;
    protected $guarded = [];
}
