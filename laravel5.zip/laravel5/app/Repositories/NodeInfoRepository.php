<?php

namespace App\Repositories;

use App\Repositories\Eloquent\AbstractRepository;

class NodeInfoRepository extends AbstractRepository
{
    function model()
    {
        return 'App\Models\NodeInfoRepository';
    }
}