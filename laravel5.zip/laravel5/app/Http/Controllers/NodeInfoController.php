<?php

namespace App\Http\Controllers;

use App\Models\NodeInfoModel;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Repositories\NodeInfoRepository as NodeInfoMgr;


class NodeInfoController extends Controller
{
//    private $nodeInfoMgr;

    public static function create()
    {
        $instance = new NodeInfoController();
        if($instance != null){
            return $instance;
        }
        return null;
    }


    public function isNodeExist($nodeName)
    {
        $isExist = false;

        $model = NodeInfoModel::where('nodeName', $nodeName)->first(['nodeName']);
        if($model != null){
            $isExist = true;
        }

        return $isExist;
    }
}
