<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Api\Contracts\Api;
use App\Repositories\Eloquent\AbstractRepository;

class NodeInfoApi extends Api
{
    public function __construct(AbstractRepository $repository)
    {
        parent::__construct($repository);
    }

    public static function create()
    {
        return ApiInstanceFactory::CREATE_FUNC(
            'NodeInfoApi',
            'NodeInfoRepository',
            'App\Repositories'
            );
    }

    public function test()
    {
        //
    }


}