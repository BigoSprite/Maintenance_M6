<?php

namespace App\ModelCenter;

use Illuminate\Database\Eloquent\Model;

class Asset_Information_Model extends Model
{
    public $table = 'asset_info';
    public $primaryKey = 'id';
    public $timestamps = false;
}
